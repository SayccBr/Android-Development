package com.example.campominado;

import java.util.Random;

import java.util.Random;

public class Matriz {
    private final int[][] tabuleiro;
    private final int tamanho;
    private final int minas;

    public Matriz(int tamanho, int minas) {
        this.tamanho = tamanho;
        this.tabuleiro = new int[tamanho][tamanho];
        this.minas = minas;
        inicializarTabuleiro();
        preencherMinas();
        calcularValoresVizinhanca();
    }

    private void inicializarTabuleiro() {
        for (int i = 0; i < tamanho; i++) {
            for (int j = 0; j < tamanho; j++) {
                tabuleiro[i][j] = 0;
            }
        }
    }

    private void preencherMinas() {
        int numMinas = minas;
        Random random = new Random();
        while (numMinas > 0) {
            int row = random.nextInt(tamanho);
            int col = random.nextInt(tamanho);
            if (tabuleiro[row][col] != -1) {
                tabuleiro[row][col] = -1; // Marcar como mina
                numMinas--;
            }
        }
    }

    private void calcularValoresVizinhanca() {
        for (int row = 0; row < tamanho; row++) {
            for (int col = 0; col < tamanho; col++) {
                if (tabuleiro[row][col] != -1) {
                    int countMinasVizinhas = contarMinasVizinhas(row, col);
                    tabuleiro[row][col] = countMinasVizinhas;
                }
            }
        }
    }

    private int contarMinasVizinhas(int x, int y) {
        int count = 0;
        for (int dr = -1; dr <= 1; dr++) {
            for (int dc = -1; dc <= 1; dc++) {
                int newRow = x + dr;
                int newCol = y + dc;
                if (newRow >= 0 && newRow < tamanho && newCol >= 0 && newCol < tamanho) {
                    if (tabuleiro[newRow][newCol] == -1) {
                        count++;
                    }
                }
            }
        }
        return count;
    }

    public int getValorCelula(int x, int y) {
        return tabuleiro[x][y];
    }
}