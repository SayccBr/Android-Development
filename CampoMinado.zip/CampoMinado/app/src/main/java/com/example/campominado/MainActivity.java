package com.example.campominado;

import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.content.pm.ActivityInfo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.gridlayout.widget.GridLayout;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private GridLayout gridLayout;
    private Matriz matriz;
    private Button[][] buttons;
    private int tamanhoTabuleiro;
    private int numeroDeMinas;

    private MediaPlayer mp;
    private int celulasClicadas = 0;
    private int marcacoes = 0;
    private boolean modoBandeira = false;

    private TextView tvClick, tvMarcacoes, tvData, tvTempo;
    private Button btReset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Se não houver parâmetros, volta ao menu
        if (getIntent() == null || !getIntent().hasExtra("tamanho")) {
            startActivity(new Intent(this, Menu.class));
            finish();
            return;
        }

        tamanhoTabuleiro = getIntent().getIntExtra("tamanho", 10);
        numeroDeMinas = getIntent().getIntExtra("minas", 10);
        boolean layoutHorizontal = getIntent().getBooleanExtra("layout_horizontal", false);

        if (layoutHorizontal) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }

        setContentView(R.layout.activity_main);

        gridLayout = findViewById(R.id.gridLayout);
        buttons = new Button[tamanhoTabuleiro][tamanhoTabuleiro];
        matriz = new Matriz(tamanhoTabuleiro, numeroDeMinas);

        mp = MediaPlayer.create(this, R.raw.som);

        tvClick = findViewById(R.id.tvClick);
        tvMarcacoes = findViewById(R.id.textView3);
        tvTempo = findViewById(R.id.tvTempo);
        tvData = findViewById(R.id.tvData);
        btReset = findViewById(R.id.btReset);

        Button btBandeira = findViewById(R.id.btBandeira);
        btBandeira.setOnClickListener(v -> modoBandeira = !modoBandeira);

        // Corrigido botão de reset
        btReset.setOnClickListener(v -> resetarJogo());

        criarTabuleiro();
        atualizarData();
        iniciarLoopAtualizacao();
    }

    private void criarTabuleiro() {
        gridLayout.removeAllViews();
        gridLayout.setRowCount(tamanhoTabuleiro);
        gridLayout.setColumnCount(tamanhoTabuleiro);

        for (int row = 0; row < tamanhoTabuleiro; row++) {
            for (int col = 0; col < tamanhoTabuleiro; col++) {
                Button button = new Button(this);
                button.setLayoutParams(new GridLayout.LayoutParams());

                int finalRow = row;
                int finalCol = col;
                button.setOnClickListener(v -> manipularClique(finalRow, finalCol, button));

                buttons[row][col] = button;
                gridLayout.addView(button);
            }
        }

        celulasClicadas = 0;
        marcacoes = 0;
        tvClick.setText("Clicks: 0");
        tvMarcacoes.setText("Marcações: 0");
    }

    private void resetarJogo() {
        matriz = new Matriz(tamanhoTabuleiro, numeroDeMinas);
        criarTabuleiro();
        Toast.makeText(this, "Jogo reiniciado!", Toast.LENGTH_SHORT).show();
    }

    private void manipularClique(int x, int y, Button button) {
        if (modoBandeira) {
            alternarBandeira(button);
            return;
        }

        if (!button.getText().toString().isEmpty()) return;

        celulasClicadas++;
        int valor = matriz.getValorCelula(x, y);
        button.setText(valor == -1 ? "💣" : String.valueOf(valor));

        if (valor == -1) {
            button.setBackgroundColor(Color.RED);
            Toast.makeText(this, "Você perdeu!", Toast.LENGTH_SHORT).show();
            revelarBombas();
            mp.start();
            desativarTabuleiro();
        } else if (valor == 0) {
            button.setBackgroundColor(Color.GRAY);
            revelarVizinhasComZero(x, y);
        } else {
            button.setBackgroundColor(Color.YELLOW);
        }

        tvClick.setText("Clicks: " + celulasClicadas);
    }

    private void alternarBandeira(Button button) {
        if (button.getText().equals("🚩")) {
            button.setText("?");
            button.setEnabled(true);
        } else if (button.getText().equals("?")) {
            button.setText("");
            button.setEnabled(true);
            marcacoes--;  // Reduz a contagem de marcações ao remover a bandeira
        } else if (button.getText().toString().isEmpty()) {
            button.setText("🚩");
            button.setEnabled(false);
            marcacoes++;
        }
        tvMarcacoes.setText("Marcações: " + marcacoes);
    }


    private void desativarTabuleiro() {
        for (Button[] row : buttons) {
            for (Button button : row) {
                button.setEnabled(false);
            }
        }
    }

    private void revelarBombas() {
        for (int row = 0; row < tamanhoTabuleiro; row++) {
            for (int col = 0; col < tamanhoTabuleiro; col++) {
                if (matriz.getValorCelula(row, col) == -1) {
                    buttons[row][col].setText("💣");
                    buttons[row][col].setBackgroundColor(Color.RED);
                }
            }
        }
    }

    private void revelarVizinhasComZero(int x, int y) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                int newX = x + dx;
                int newY = y + dy;

                if (newX >= 0 && newX < tamanhoTabuleiro && newY >= 0 && newY < tamanhoTabuleiro) {
                    Button vizinho = buttons[newX][newY];
                    if (!vizinho.getText().toString().isEmpty()) continue;

                    int valor = matriz.getValorCelula(newX, newY);
                    vizinho.setText(valor == 0 ? " " : String.valueOf(valor));
                    vizinho.setBackgroundColor(valor == 0 ? Color.GRAY : Color.YELLOW);

                    if (valor == 0) revelarVizinhasComZero(newX, newY);
                }
            }
        }
    }

    private void iniciarLoopAtualizacao() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                atualizarHora();
                handler.postDelayed(this, 1000);
            }
        }, 1000);
    }

    private void atualizarData() {
        tvData.setText(new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date()));
    }

    private void atualizarHora() {
        tvTempo.setText(new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()));
    }

    public void Voltar(View view) {
        startActivity(new Intent(this, Menu.class));
        finish();
    }
}
