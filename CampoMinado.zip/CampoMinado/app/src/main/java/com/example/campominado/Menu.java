package com.example.campominado;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }

    public void iniciarJogo(int tamanho, int minas, boolean horizontal) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("tamanho", tamanho);
        intent.putExtra("minas", minas);
        intent.putExtra("layout_horizontal", horizontal);
        startActivity(intent);
    }

    public void Facil(View view) { iniciarJogo(9, 10, false); }
    public void Medio(View view) { iniciarJogo(14, 30, false); }
    public void Dificil(View view) { iniciarJogo(14, 50, true); }
    public void Personalizado(View view) { iniciarJogo(16, 60, true); }
}
